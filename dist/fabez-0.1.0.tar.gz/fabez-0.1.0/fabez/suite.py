# -*- coding: utf-8 -*-

from fabez.lang import lang_python
from fabez.api import *


def suite_pythonic(branch='master'):
    lang_python(branch)




    pass



# def suite_php(branch='master',user='webuser',work_connections=1024,work_process=10):
#
#     cmd_useradd(user)
#     server_nginx(user=user,worker_connections=work_connections,worker_processes=work_process)
#
#
#     pass